Module Module1
    Sub Main()
        ' Task 5 - shop till
        ' Input the price of an item and the amount the customer pays.
        ' Output "Not enough money" if the amount paid is less than the price,
        ' otherwise calculate and output the change with a suitable message.
        ' Test data: 4.50 and 10 / 8 and 5 / 3 and 3

        ' Declare your variables here (use Double for money)


        ' Input the price and the amount paid


        ' If ... Then ... Else ... End If


        Console.ReadKey()
    End Sub
End Module
