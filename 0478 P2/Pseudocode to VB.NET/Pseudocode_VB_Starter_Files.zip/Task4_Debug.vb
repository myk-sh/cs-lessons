Module Module1
    Sub Main()
        ' Task 4 - this program has FOUR errors.
        ' It should output "Well done" for a score of 50 or more, otherwise "Try again".
        ' Find and fix the errors, then run the program to test it.
        Dim Score As Integer
        Console.WriteLine("Enter your score")
        Score ← Console.ReadLine()
        If Score >= 50
            Console.WriteLine("Well done")
        Else
            Console.WriteLine(Try again)
        ENDIF
        Console.ReadKey()
    End Sub
End Module
